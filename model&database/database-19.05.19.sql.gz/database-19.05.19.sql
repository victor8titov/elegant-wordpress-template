# WordPress MySQL database migration
#
# Generated: Sunday 19. May 2019 08:29 UTC
# Hostname: 192.168.43.34
# Database: `elegant`
# URL: //portfolio.elegant
# Path: C:/open_server/OSPanel/domains/PORTFOLIO.Elegant
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, attachment, customize_changeset, nav_menu_item, page, people, post, project, work
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-04-17 17:03:21', '2019-04-17 17:03:21', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0),
(2, 75, 'admin', 'victor8titov@yandex.ru', '', '127.0.0.1', '2019-05-16 06:24:15', '2019-05-16 06:24:15', 'ываываываыв вывфаываывва\r\nывваываывв\r\nаыв\r\nа\r\nыва\r\nыва', 0, '1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0', '', 0, 1) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=767 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://portfolio.elegant', 'yes'),
(2, 'home', 'http://portfolio.elegant', 'yes'),
(3, 'blogname', 'Elegant', 'yes'),
(4, 'blogdescription', 'Just', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'titov8victor@yandex.ru', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '2', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:133:{s:7:"work/?$";s:24:"index.php?post_type=work";s:37:"work/feed/(feed|rdf|rss|rss2|atom)/?$";s:41:"index.php?post_type=work&feed=$matches[1]";s:32:"work/(feed|rdf|rss|rss2|atom)/?$";s:41:"index.php?post_type=work&feed=$matches[1]";s:24:"work/page/([0-9]{1,})/?$";s:42:"index.php?post_type=work&paged=$matches[1]";s:10:"project/?$";s:27:"index.php?post_type=project";s:40:"project/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=project&feed=$matches[1]";s:35:"project/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=project&feed=$matches[1]";s:27:"project/page/([0-9]{1,})/?$";s:45:"index.php?post_type=project&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:32:"work/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"work/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"work/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"work/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"work/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"work/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"work/([^/]+)/embed/?$";s:37:"index.php?work=$matches[1]&embed=true";s:25:"work/([^/]+)/trackback/?$";s:31:"index.php?work=$matches[1]&tb=1";s:45:"work/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?work=$matches[1]&feed=$matches[2]";s:40:"work/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?work=$matches[1]&feed=$matches[2]";s:33:"work/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?work=$matches[1]&paged=$matches[2]";s:40:"work/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?work=$matches[1]&cpage=$matches[2]";s:29:"work/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?work=$matches[1]&page=$matches[2]";s:21:"work/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"work/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"work/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"work/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"work/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"work/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:35:"project/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"project/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"project/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"project/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"project/([^/]+)/embed/?$";s:40:"index.php?project=$matches[1]&embed=true";s:28:"project/([^/]+)/trackback/?$";s:34:"index.php?project=$matches[1]&tb=1";s:48:"project/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?project=$matches[1]&feed=$matches[2]";s:43:"project/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?project=$matches[1]&feed=$matches[2]";s:36:"project/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&paged=$matches[2]";s:43:"project/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&cpage=$matches[2]";s:32:"project/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?project=$matches[1]&page=$matches[2]";s:24:"project/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"project/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"project/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"project/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=19&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:33:"classic-editor/classic-editor.php";i:1;s:21:"meta-box/meta-box.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'elegant', 'yes'),
(41, 'stylesheet', 'elegant', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '44719', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:3;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:33:"classic-editor/classic-editor.php";a:2:{i:0;s:14:"Classic_Editor";i:1;s:9:"uninstall";}}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '23', 'yes'),
(84, 'page_on_front', '19', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'initial_db_version', '44719', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:3;a:3:{s:5:"title";s:0:"";s:6:"number";i:4;s:9:"show_date";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:12:"sidebar-main";a:3:{i:0;s:14:"recent-posts-3";i:1;s:12:"categories-3";i:2;s:16:"recent-project-2";}s:14:"sidebar-simple";a:1:{i:0;s:16:"recent-project-3";}s:9:"sidebar-1";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'nonce_key', 'ynU:Ra^e@.+yc?Ei$W^k/Yr=Tb.%KB?rr|H1Kv@+kTdbt}GS&,uB!Ne)Q>6I3?(2', 'no'),
(109, 'nonce_salt', 'FuP/LYS(zK3Qr^Hhs?Jw_SrW1jl-[`GGKm4B^NebBQ;>1fb=Uw|zV}@kpfJ{v=^?', 'no'),
(110, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'cron', 'a:5:{i:1558256602;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1558285402;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1558285442;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1558285465;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(114, 'theme_mods_twentynineteen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1555521560;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(117, 'auth_key', '/Sq_JHsO**GzkIp^#HXIMTISK.TPk/9slp<]YGWn}g!=C%AvE9Vcm <Yu1u!CRr2', 'no'),
(118, 'auth_salt', '=*pj5M${?5g4~+GN+6&GE1^F=J/pZgDB3cZd/%+HAS:;5wP5. w+4v>QH~th+1Y:', 'no'),
(119, 'logged_in_key', 'y@JJl2[j{&THu9_~_8w.=/b_,e}]{u&~`ebNx=dluplujoU50I7)N[:]/;9F9 S0', 'no'),
(120, 'logged_in_salt', '^Ui!xO:a0yFR.5#E[tOZ>CP!:UAORQjT-`xjWpmUiqiYA*D>.2)Yi#@~~]w&bn:<', 'no'),
(127, 'can_compress_scripts', '1', 'no'),
(144, 'current_theme', 'Elegant', 'yes'),
(145, 'theme_mods_elegant', 'a:5:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:6:"menu-1";i:2;s:11:"header_menu";i:2;}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1555592504;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}s:11:"custom_logo";i:38;}', 'yes'),
(146, 'theme_switched', '', 'yes'),
(148, 'theme_mods_JointsWP', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1555522668;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:8:"sidebar1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"offcanvas";a:0:{}}}}', 'yes'),
(154, 'theme_mods_eleelegant', 'a:2:{s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1555591125;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(177, 'WPLANG', '', 'yes'),
(178, 'new_admin_email', 'titov8victor@yandex.ru', 'yes'),
(202, 'recently_activated', 'a:0:{}', 'yes'),
(211, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:1:{i:0;i:2;}}', 'yes'),
(275, 'widget_true_top_widget', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:14:"posts_per_page";s:1:"5";}s:12:"_multiwidget";i:1;}', 'yes'),
(277, 'widget_recent-project', 'a:3:{i:2;a:3:{s:5:"title";s:8:"Projects";s:6:"number";i:4;s:9:"show_date";b:0;}i:3;a:3:{s:5:"title";s:0:"";s:6:"number";i:5;s:9:"show_date";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(283, 'category_children', 'a:0:{}', 'yes'),
(736, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1558254573;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=473 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(4, 2, '_edit_lock', '1555676193:1'),
(5, 2, '_wp_trash_meta_status', 'publish'),
(6, 2, '_wp_trash_meta_time', '1555676346'),
(7, 2, '_wp_desired_post_slug', 'sample-page'),
(8, 3, '_wp_trash_meta_status', 'draft'),
(9, 3, '_wp_trash_meta_time', '1555676350'),
(10, 3, '_wp_desired_post_slug', 'privacy-policy'),
(13, 15, '_edit_last', '1'),
(14, 15, '_wp_page_template', 'about.php'),
(15, 15, '_edit_lock', '1556433801:1'),
(16, 17, '_edit_last', '1'),
(17, 17, '_edit_lock', '1555677724:1'),
(18, 17, '_wp_page_template', 'contact.php'),
(19, 19, '_edit_last', '1'),
(21, 19, '_edit_lock', '1558183179:1'),
(22, 23, '_edit_last', '1'),
(23, 23, '_edit_lock', '1556457007:1'),
(25, 25, '_menu_item_type', 'post_type'),
(26, 25, '_menu_item_menu_item_parent', '0'),
(27, 25, '_menu_item_object_id', '19'),
(28, 25, '_menu_item_object', 'page'),
(29, 25, '_menu_item_target', ''),
(30, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(31, 25, '_menu_item_xfn', ''),
(32, 25, '_menu_item_url', ''),
(34, 26, '_menu_item_type', 'post_type'),
(35, 26, '_menu_item_menu_item_parent', '0'),
(36, 26, '_menu_item_object_id', '15'),
(37, 26, '_menu_item_object', 'page'),
(38, 26, '_menu_item_target', ''),
(39, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(40, 26, '_menu_item_xfn', ''),
(41, 26, '_menu_item_url', ''),
(43, 27, '_menu_item_type', 'post_type'),
(44, 27, '_menu_item_menu_item_parent', '0'),
(45, 27, '_menu_item_object_id', '23'),
(46, 27, '_menu_item_object', 'page'),
(47, 27, '_menu_item_target', ''),
(48, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(49, 27, '_menu_item_xfn', ''),
(50, 27, '_menu_item_url', ''),
(52, 28, '_menu_item_type', 'post_type'),
(53, 28, '_menu_item_menu_item_parent', '0'),
(54, 28, '_menu_item_object_id', '17'),
(55, 28, '_menu_item_object', 'page'),
(56, 28, '_menu_item_target', ''),
(57, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(58, 28, '_menu_item_xfn', ''),
(59, 28, '_menu_item_url', ''),
(61, 29, '_menu_item_type', 'post_type'),
(62, 29, '_menu_item_menu_item_parent', '0'),
(63, 29, '_menu_item_object_id', '19'),
(64, 29, '_menu_item_object', 'page'),
(65, 29, '_menu_item_target', ''),
(66, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(67, 29, '_menu_item_xfn', ''),
(68, 29, '_menu_item_url', ''),
(69, 29, '_menu_item_orphaned', '1555678035'),
(70, 30, '_edit_last', '1'),
(71, 30, '_edit_lock', '1557920004:1'),
(72, 31, '_edit_last', '1'),
(73, 31, '_edit_lock', '1556107362:1'),
(74, 1, '_wp_trash_meta_status', 'publish'),
(75, 1, '_wp_trash_meta_time', '1555678785'),
(76, 1, '_wp_desired_post_slug', 'hello-world'),
(77, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(78, 33, '_edit_last', '1'),
(81, 33, '_edit_lock', '1555678660:1'),
(82, 30, '_wp_page_template', 'default'),
(83, 35, '_menu_item_type', 'post_type_archive'),
(84, 35, '_menu_item_menu_item_parent', '0'),
(85, 35, '_menu_item_object_id', '-17'),
(86, 35, '_menu_item_object', 'project'),
(87, 35, '_menu_item_target', ''),
(88, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(89, 35, '_menu_item_xfn', ''),
(90, 35, '_menu_item_url', ''),
(92, 36, '_menu_item_type', 'post_type_archive'),
(93, 36, '_menu_item_menu_item_parent', '0'),
(94, 36, '_menu_item_object_id', '-13'),
(95, 36, '_menu_item_object', 'work'),
(96, 36, '_menu_item_target', ''),
(97, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(98, 36, '_menu_item_xfn', ''),
(99, 36, '_menu_item_url', ''),
(101, 37, '_wp_attached_file', '2019/04/logo.png'),
(102, 37, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:190;s:6:"height";i:42;s:4:"file";s:16:"2019/04/logo.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"logo-150x42.png";s:5:"width";i:150;s:6:"height";i:42;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(103, 38, '_wp_attached_file', '2019/04/cropped-logo.png'),
(104, 38, '_wp_attachment_context', 'custom-logo'),
(105, 38, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:190;s:6:"height";i:42;s:4:"file";s:24:"2019/04/cropped-logo.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"cropped-logo-150x42.png";s:5:"width";i:150;s:6:"height";i:42;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(106, 39, '_wp_trash_meta_status', 'publish'),
(107, 39, '_wp_trash_meta_time', '1555682102'),
(108, 40, '_edit_last', '1'),
(109, 40, '_wp_page_template', 'default'),
(110, 40, '_edit_lock', '1557920004:1'),
(129, 50, '_edit_last', '1'),
(130, 50, '_edit_lock', '1557920003:1'),
(133, 50, '_wp_page_template', 'default') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(134, 51, '_edit_last', '1'),
(135, 51, '_edit_lock', '1557920003:1'),
(138, 51, '_wp_page_template', 'default'),
(139, 52, '_edit_last', '1'),
(140, 52, '_edit_lock', '1557920003:1'),
(142, 52, '_wp_page_template', 'default'),
(143, 53, '_edit_last', '1'),
(144, 53, '_edit_lock', '1557920002:1'),
(145, 53, '_wp_page_template', 'default'),
(148, 54, '_edit_last', '1'),
(149, 54, '_edit_lock', '1557920002:1'),
(151, 54, '_wp_page_template', 'default'),
(152, 55, '_edit_last', '1'),
(153, 55, '_edit_lock', '1557986818:1'),
(156, 55, '_wp_page_template', 'default'),
(162, 58, '_wp_attached_file', '2019/04/cd-container-clmn-1-img1.jpg'),
(163, 58, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:486;s:6:"height";i:305;s:4:"file";s:36:"2019/04/cd-container-clmn-1-img1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"cd-container-clmn-1-img1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:36:"cd-container-clmn-1-img1-300x188.jpg";s:5:"width";i:300;s:6:"height";i:188;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(164, 55, '_thumbnail_id', '58'),
(165, 59, '_wp_attached_file', '2019/04/cd-container-clmn-2.jpg'),
(166, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:323;s:6:"height";i:402;s:4:"file";s:31:"2019/04/cd-container-clmn-2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"cd-container-clmn-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"cd-container-clmn-2-241x300.jpg";s:5:"width";i:241;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(167, 60, '_wp_attached_file', '2019/04/cd-container-clmn-3.jpg'),
(168, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:485;s:6:"height";i:304;s:4:"file";s:31:"2019/04/cd-container-clmn-3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"cd-container-clmn-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"cd-container-clmn-3-300x188.jpg";s:5:"width";i:300;s:6:"height";i:188;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(169, 61, '_wp_attached_file', '2019/04/cd-container-clmn-4.jpg'),
(170, 61, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:317;s:6:"height";i:396;s:4:"file";s:31:"2019/04/cd-container-clmn-4.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"cd-container-clmn-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"cd-container-clmn-4-240x300.jpg";s:5:"width";i:240;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(171, 62, '_wp_attached_file', '2019/04/cd-container-clmn-5.jpg'),
(172, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:484;s:6:"height";i:302;s:4:"file";s:31:"2019/04/cd-container-clmn-5.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"cd-container-clmn-5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"cd-container-clmn-5-300x187.jpg";s:5:"width";i:300;s:6:"height";i:187;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(173, 63, '_wp_attached_file', '2019/04/cd-container-clmn-6.jpg'),
(174, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:489;s:6:"height";i:306;s:4:"file";s:31:"2019/04/cd-container-clmn-6.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"cd-container-clmn-6-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"cd-container-clmn-6-300x188.jpg";s:5:"width";i:300;s:6:"height";i:188;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(175, 64, '_wp_attached_file', '2019/04/cd-container-clmn-7.jpg'),
(176, 64, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:496;s:6:"height";i:309;s:4:"file";s:31:"2019/04/cd-container-clmn-7.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"cd-container-clmn-7-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"cd-container-clmn-7-300x187.jpg";s:5:"width";i:300;s:6:"height";i:187;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(177, 65, '_wp_attached_file', '2019/04/cd-container-clmn-8.jpg'),
(178, 65, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:318;s:6:"height";i:303;s:4:"file";s:31:"2019/04/cd-container-clmn-8.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"cd-container-clmn-8-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"cd-container-clmn-8-300x286.jpg";s:5:"width";i:300;s:6:"height";i:286;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(179, 40, '_thumbnail_id', '64'),
(180, 52, '_thumbnail_id', '61'),
(181, 53, '_thumbnail_id', '60'),
(182, 50, '_thumbnail_id', '63'),
(183, 51, '_thumbnail_id', '62'),
(184, 54, '_thumbnail_id', '59'),
(185, 66, '_edit_last', '1'),
(186, 66, '_edit_lock', '1555921909:1'),
(187, 67, '_wp_attached_file', '2019/04/cd-container-clmn-7-1-e1555922020186.jpg'),
(188, 67, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:219;s:6:"height";i:308;s:4:"file";s:48:"2019/04/cd-container-clmn-7-1-e1555922020186.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:48:"cd-container-clmn-7-1-e1555922020186-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:48:"cd-container-clmn-7-1-e1555922020186-213x300.jpg";s:5:"width";i:213;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(189, 67, '_wp_attachment_backup_sizes', 'a:3:{s:9:"full-orig";a:3:{s:5:"width";i:496;s:6:"height";i:309;s:4:"file";s:25:"cd-container-clmn-7-1.jpg";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:33:"cd-container-clmn-7-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"medium-orig";a:4:{s:4:"file";s:33:"cd-container-clmn-7-1-300x187.jpg";s:5:"width";i:300;s:6:"height";i:187;s:9:"mime-type";s:10:"image/jpeg";}}'),
(190, 66, '_thumbnail_id', '67'),
(191, 66, '_wp_page_template', 'default'),
(192, 66, '_wp_trash_meta_status', 'publish'),
(193, 66, '_wp_trash_meta_time', '1555922056'),
(194, 66, '_wp_desired_post_slug', 'work-9'),
(195, 30, '_thumbnail_id', '65'),
(197, 31, '_wp_page_template', 'default'),
(198, 33, '_wp_trash_meta_status', 'publish'),
(199, 33, '_wp_trash_meta_time', '1556108399'),
(200, 33, '_wp_desired_post_slug', 'post-1'),
(201, 69, '_edit_last', '1'),
(202, 69, '_edit_lock', '1556942381:1'),
(203, 70, '_edit_last', '1'),
(204, 70, '_edit_lock', '1556942376:1'),
(205, 71, '_edit_last', '1'),
(206, 71, '_edit_lock', '1556942368:1'),
(207, 72, '_edit_last', '1'),
(208, 72, '_edit_lock', '1556941606:1'),
(209, 73, '_edit_last', '1'),
(210, 73, '_edit_lock', '1556941599:1'),
(211, 74, '_edit_last', '1'),
(212, 74, '_edit_lock', '1556941575:1'),
(213, 75, '_edit_last', '1'),
(214, 75, '_edit_lock', '1556941583:1'),
(215, 76, '_edit_last', '1'),
(216, 76, '_edit_lock', '1556941590:1'),
(217, 77, '_wp_attached_file', '2019/04/contact-mobile.jpg'),
(218, 77, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:607;s:6:"height";i:404;s:4:"file";s:26:"2019/04/contact-mobile.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"contact-mobile-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"contact-mobile-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(219, 78, '_wp_attached_file', '2019/04/img1.jpg'),
(220, 78, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:627;s:6:"height";i:417;s:4:"file";s:16:"2019/04/img1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"img1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"img1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(221, 69, '_thumbnail_id', '77'),
(224, 70, '_thumbnail_id', '78'),
(227, 71, '_thumbnail_id', '77'),
(230, 72, '_thumbnail_id', '78'),
(233, 73, '_thumbnail_id', '77'),
(236, 76, '_thumbnail_id', '78'),
(239, 75, '_thumbnail_id', '77'),
(242, 74, '_thumbnail_id', '78'),
(245, 31, '_wp_trash_meta_status', 'publish'),
(246, 31, '_wp_trash_meta_time', '1556108856'),
(247, 31, '_wp_desired_post_slug', 'poject-1'),
(248, 87, '_edit_last', '1'),
(249, 87, '_edit_lock', '1556125971:1'),
(250, 88, '_edit_last', '1'),
(251, 88, '_edit_lock', '1556108944:1'),
(252, 89, '_edit_last', '1'),
(253, 89, '_edit_lock', '1556372659:1'),
(254, 90, '_edit_last', '1'),
(255, 90, '_edit_lock', '1557755477:1'),
(256, 91, '_edit_last', '1'),
(257, 91, '_edit_lock', '1556108940:1'),
(258, 92, '_edit_last', '1'),
(259, 92, '_edit_lock', '1556108939:1'),
(260, 93, '_edit_last', '1'),
(261, 93, '_edit_lock', '1556108938:1'),
(262, 87, '_thumbnail_id', '58'),
(263, 87, '_wp_page_template', 'default') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(264, 88, '_thumbnail_id', '59'),
(265, 88, '_wp_page_template', 'default'),
(266, 93, '_thumbnail_id', '64'),
(267, 93, '_wp_page_template', 'default'),
(268, 92, '_thumbnail_id', '63'),
(269, 92, '_wp_page_template', 'default'),
(270, 91, '_thumbnail_id', '62'),
(271, 91, '_wp_page_template', 'default'),
(272, 90, '_thumbnail_id', '61'),
(273, 90, '_wp_page_template', 'default'),
(274, 89, '_thumbnail_id', '58'),
(275, 89, '_wp_page_template', 'default'),
(276, 95, '_wp_attached_file', '2019/04/img2.jpg'),
(277, 95, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:666;s:6:"height";i:416;s:4:"file";s:16:"2019/04/img2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"img2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"img2-300x187.jpg";s:5:"width";i:300;s:6:"height";i:187;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(278, 96, '_wp_attached_file', '2019/04/img3.jpg'),
(279, 96, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:665;s:6:"height";i:832;s:4:"file";s:16:"2019/04/img3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"img3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"img3-240x300.jpg";s:5:"width";i:240;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(280, 97, '_wp_attached_file', '2019/04/img4.jpg'),
(281, 97, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:665;s:6:"height";i:416;s:4:"file";s:16:"2019/04/img4.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"img4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"img4-300x188.jpg";s:5:"width";i:300;s:6:"height";i:188;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(285, 89, 'images', '95'),
(286, 89, 'images', '96'),
(287, 89, 'images', '97'),
(288, 19, '_wp_page_template', 'main.php'),
(289, 19, 'about_show', '1'),
(290, 19, 'about_title', 'Tell The World About Yourself'),
(291, 19, 'about_text', 'Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc, fiant sollemnes in futurum.'),
(292, 19, 'work_show', '1'),
(293, 19, 'people_show', '1'),
(294, 19, 'people_title', 'The Amazing People Behind This'),
(295, 19, 'people_text', 'Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum.'),
(296, 19, 'post_show', '1'),
(297, 19, 'contact_show', '1'),
(298, 19, 'contact_location', 'a:1:{i:0;s:40:"198 West 21th Street, New York, NY 10010";}'),
(299, 19, 'contact_fax', 'a:2:{i:0;s:20:"+88 (0) 202 0000 000";i:1;s:20:"+88 (0) 202 0000 000";}'),
(300, 19, 'contact_phone', 'a:2:{i:0;s:19:"+88 (0) 101 0000000";i:1;s:19:"+88 (0) 101 0000000";}'),
(301, 19, 'contact_email', 'a:2:{i:0;s:19:"elegant@elegant.com";i:1;s:22:"commercial@elegant.com";}'),
(302, 101, '_edit_last', '1'),
(303, 101, '_edit_lock', '1556434999:1'),
(304, 102, '_wp_attached_file', '2019/04/man1.jpg'),
(305, 102, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:246;s:6:"height";i:192;s:4:"file";s:16:"2019/04/man1.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"man1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(306, 101, '_thumbnail_id', '102'),
(307, 101, 'people_prof', 'ceo'),
(308, 103, '_edit_last', '1'),
(309, 103, '_edit_lock', '1556434999:1'),
(310, 105, '_wp_attached_file', '2019/04/man2.jpg'),
(311, 105, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:244;s:6:"height";i:192;s:4:"file";s:16:"2019/04/man2.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"man2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(312, 103, '_thumbnail_id', '105'),
(313, 103, 'people_prof', 'Designer'),
(314, 104, '_edit_last', '1'),
(315, 104, '_edit_lock', '1558175557:1'),
(316, 106, '_wp_attached_file', '2019/04/man3.jpg'),
(317, 106, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:246;s:6:"height";i:192;s:4:"file";s:16:"2019/04/man3.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"man3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(318, 104, '_thumbnail_id', '106'),
(319, 104, 'people_prof', 'Developer'),
(320, 19, 'about_link', 'http://portfolio.elegant/about/'),
(399, 90, 'images', '64'),
(400, 90, 'images', '63'),
(401, 90, 'images', '62'),
(402, 90, 'images', '61'),
(407, 55, 'images', '97'),
(408, 55, 'images', '96'),
(409, 55, 'images', '95'),
(410, 55, 'images', '62'),
(411, 55, 'images', '61'),
(412, 55, 'images', '60'),
(413, 55, 'images', '67'),
(414, 55, 'images', '59'),
(415, 55, 'images', '64'),
(416, 54, 'images', '58'),
(417, 54, 'images', '97'),
(418, 54, 'images', '96'),
(419, 54, 'images', '95'),
(420, 54, 'images', '67'),
(421, 54, 'images', '65'),
(422, 54, 'images', '64'),
(423, 54, 'images', '63'),
(424, 54, 'images', '62'),
(425, 54, 'images', '61'),
(426, 54, 'images', '60'),
(427, 54, 'images', '59'),
(428, 53, 'images', '97'),
(429, 53, 'images', '96'),
(430, 53, 'images', '95'),
(431, 53, 'images', '67'),
(432, 53, 'images', '65'),
(433, 53, 'images', '64'),
(434, 53, 'images', '63'),
(435, 53, 'images', '62'),
(436, 53, 'images', '61'),
(437, 53, 'images', '60'),
(438, 53, 'images', '59'),
(439, 53, 'images', '58'),
(440, 52, 'images', '65'),
(441, 52, 'images', '64'),
(442, 52, 'images', '63'),
(443, 52, 'images', '62'),
(444, 52, 'images', '61'),
(445, 51, 'images', '58'),
(446, 51, 'images', '59'),
(447, 51, 'images', '60'),
(448, 51, 'images', '95') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(449, 51, 'images', '97'),
(450, 50, 'images', '65'),
(451, 50, 'images', '63'),
(452, 50, 'images', '62'),
(453, 50, 'images', '61'),
(454, 50, 'images', '96'),
(455, 50, 'images', '95'),
(456, 40, 'images', '59'),
(457, 40, 'images', '58'),
(458, 40, 'images', '63'),
(459, 40, 'images', '62'),
(460, 40, 'images', '95'),
(467, 30, 'images', '58'),
(468, 30, 'images', '59'),
(469, 30, 'images', '60'),
(470, 30, 'images', '67'),
(471, 30, 'images', '65'),
(472, 30, 'images', '64') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-04-17 17:03:21', '2019-04-17 17:03:21', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2019-04-19 12:59:45', '2019-04-19 12:59:45', '', 0, 'http://portfolio.elegant/?p=1', 0, 'post', '', 1),
(2, 1, '2019-04-17 17:03:21', '2019-04-17 17:03:21', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://portfolio.elegant/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2019-04-19 12:19:06', '2019-04-19 12:19:06', '', 0, 'http://portfolio.elegant/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-04-17 17:03:21', '2019-04-17 17:03:21', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://portfolio.elegant.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2019-04-19 12:19:10', '2019-04-19 12:19:10', '', 0, 'http://portfolio.elegant/?page_id=3', 0, 'page', '', 0),
(11, 1, '2019-04-19 12:19:06', '2019-04-19 12:19:06', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://portfolio.elegant/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2019-04-19 12:19:06', '2019-04-19 12:19:06', '', 2, 'http://portfolio.elegant/2019/04/19/2-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2019-04-19 12:19:10', '2019-04-19 12:19:10', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://portfolio.elegant.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2019-04-19 12:19:10', '2019-04-19 12:19:10', '', 3, 'http://portfolio.elegant/2019/04/19/3-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2019-04-19 12:44:05', '2019-04-19 12:44:05', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2019-04-19 12:44:05', '2019-04-19 12:44:05', '', 0, 'http://portfolio.elegant/?page_id=15', 0, 'page', '', 0),
(16, 1, '2019-04-19 12:44:05', '2019-04-19 12:44:05', '', 'About', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2019-04-19 12:44:05', '2019-04-19 12:44:05', '', 15, 'http://portfolio.elegant/2019/04/19/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2019-04-19 12:44:23', '2019-04-19 12:44:23', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2019-04-19 12:44:23', '2019-04-19 12:44:23', '', 0, 'http://portfolio.elegant/?page_id=17', 0, 'page', '', 0),
(18, 1, '2019-04-19 12:44:23', '2019-04-19 12:44:23', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2019-04-19 12:44:23', '2019-04-19 12:44:23', '', 17, 'http://portfolio.elegant/2019/04/19/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2019-04-19 12:44:34', '2019-04-19 12:44:34', '', 'Main', '', 'publish', 'closed', 'closed', '', 'main', '', '', '2019-05-18 10:44:49', '2019-05-18 10:44:49', '', 0, 'http://portfolio.elegant/?page_id=19', 0, 'page', '', 0),
(20, 1, '2019-04-19 12:44:34', '2019-04-19 12:44:34', '', 'Main', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-04-19 12:44:34', '2019-04-19 12:44:34', '', 19, 'http://portfolio.elegant/2019/04/19/19-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2019-04-19 12:46:45', '2019-04-19 12:46:45', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2019-04-19 12:46:45', '2019-04-19 12:46:45', '', 0, 'http://portfolio.elegant/?page_id=23', 0, 'page', '', 0),
(24, 1, '2019-04-19 12:46:45', '2019-04-19 12:46:45', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2019-04-19 12:46:45', '2019-04-19 12:46:45', '', 23, 'http://portfolio.elegant/2019/04/19/23-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2019-04-19 12:49:19', '2019-04-19 12:49:19', ' ', '', '', 'publish', 'closed', 'closed', '', '25', '', '', '2019-05-03 16:50:00', '2019-05-03 16:50:00', '', 0, 'http://portfolio.elegant/?p=25', 1, 'nav_menu_item', '', 0),
(26, 1, '2019-04-19 12:49:19', '2019-04-19 12:49:19', ' ', '', '', 'publish', 'closed', 'closed', '', '26', '', '', '2019-05-03 16:50:00', '2019-05-03 16:50:00', '', 0, 'http://portfolio.elegant/?p=26', 2, 'nav_menu_item', '', 0),
(27, 1, '2019-04-19 12:49:19', '2019-04-19 12:49:19', ' ', '', '', 'publish', 'closed', 'closed', '', '27', '', '', '2019-05-03 16:50:00', '2019-05-03 16:50:00', '', 0, 'http://portfolio.elegant/?p=27', 4, 'nav_menu_item', '', 0),
(28, 1, '2019-04-19 12:49:19', '2019-04-19 12:49:19', ' ', '', '', 'publish', 'closed', 'closed', '', '28', '', '', '2019-05-03 16:50:00', '2019-05-03 16:50:00', '', 0, 'http://portfolio.elegant/?p=28', 3, 'nav_menu_item', '', 0),
(29, 1, '2019-04-19 12:47:15', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-19 12:47:15', '0000-00-00 00:00:00', '', 0, 'http://portfolio.elegant/?p=29', 1, 'nav_menu_item', '', 0),
(30, 1, '2019-04-19 12:51:39', '2019-04-19 12:51:39', '&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'work 1', '', 'publish', 'closed', 'closed', '', 'work-1', '', '', '2019-05-15 11:35:25', '2019-05-15 11:35:25', '', 0, 'http://portfolio.elegant/?post_type=work&#038;p=30', 0, 'work', '', 0),
(31, 1, '2019-04-19 12:51:55', '2019-04-19 12:51:55', 'sdfsf', 'poject -1', '', 'trash', 'closed', 'closed', '', 'poject-1__trashed', '', '', '2019-04-24 12:27:36', '2019-04-24 12:27:36', '', 0, 'http://portfolio.elegant/?post_type=project&#038;p=31', 0, 'project', '', 0),
(32, 1, '2019-04-19 12:59:45', '2019-04-19 12:59:45', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-04-19 12:59:45', '2019-04-19 12:59:45', '', 1, 'http://portfolio.elegant/2019/04/19/1-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2019-04-19 12:59:54', '2019-04-19 12:59:54', '', 'post-1', '', 'trash', 'open', 'open', '', 'post-1__trashed', '', '', '2019-04-24 12:19:59', '2019-04-24 12:19:59', '', 0, 'http://portfolio.elegant/?p=33', 0, 'post', '', 0),
(34, 1, '2019-04-19 12:59:54', '2019-04-19 12:59:54', '', 'post-1', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2019-04-19 12:59:54', '2019-04-19 12:59:54', '', 33, 'http://portfolio.elegant/2019/04/19/33-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2019-04-19 13:06:44', '2019-04-19 13:06:44', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2019-05-03 16:50:00', '2019-05-03 16:50:00', '', 0, 'http://portfolio.elegant/?p=35', 5, 'nav_menu_item', '', 0),
(36, 1, '2019-04-19 13:06:44', '2019-04-19 13:06:44', ' ', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2019-05-03 16:50:00', '2019-05-03 16:50:00', '', 0, 'http://portfolio.elegant/?p=36', 6, 'nav_menu_item', '', 0),
(37, 1, '2019-04-19 13:53:48', '2019-04-19 13:53:48', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2019-04-19 13:53:48', '2019-04-19 13:53:48', '', 0, 'http://portfolio.elegant/wp-content/uploads/2019/04/logo.png', 0, 'attachment', 'image/png', 0),
(38, 1, '2019-04-19 13:54:20', '2019-04-19 13:54:20', 'http://portfolio.elegant/wp-content/uploads/2019/04/cropped-logo.png', 'cropped-logo.png', '', 'inherit', 'open', 'closed', '', 'cropped-logo-png', '', '', '2019-04-19 13:54:20', '2019-04-19 13:54:20', '', 0, 'http://portfolio.elegant/wp-content/uploads/2019/04/cropped-logo.png', 0, 'attachment', 'image/png', 0),
(39, 1, '2019-04-19 13:55:02', '2019-04-19 13:55:02', '{"elegant::custom_logo":{"value":38,"type":"theme_mod","user_id":1,"date_modified_gmt":"2019-04-19 13:55:02"}}', '', '', 'trash', 'closed', 'closed', '', '8103ec92-84df-4ace-916c-a1457910df2f', '', '', '2019-04-19 13:55:02', '2019-04-19 13:55:02', '', 0, 'http://portfolio.elegant/2019/04/19/8103ec92-84df-4ace-916c-a1457910df2f/', 0, 'customize_changeset', '', 0),
(40, 1, '2019-04-22 06:26:20', '2019-04-22 06:26:20', '&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'work 2', '', 'publish', 'closed', 'closed', '', 'work-2', '', '', '2019-05-15 11:34:19', '2019-05-15 11:34:19', '', 0, 'http://portfolio.elegant/?post_type=work&#038;p=40', 0, 'work', '', 0),
(49, 1, '2019-04-22 06:46:01', '2019-04-22 06:46:01', '', 'work 1', '', 'inherit', 'closed', 'closed', '', '30-autosave-v1', '', '', '2019-04-22 06:46:01', '2019-04-22 06:46:01', '', 30, 'http://portfolio.elegant/2019/04/22/30-autosave-v1/', 0, 'revision', '', 0),
(50, 1, '2019-04-22 06:50:36', '2019-04-22 06:50:36', '&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\r\n\r\n&nbsp;', 'work 3', '', 'publish', 'closed', 'closed', '', 'work-3', '', '', '2019-05-15 11:34:08', '2019-05-15 11:34:08', '', 0, 'http://portfolio.elegant/?post_type=work&#038;p=50', 0, 'work', '', 0),
(51, 1, '2019-04-22 06:52:11', '2019-04-22 06:52:11', '&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'work 4', '', 'publish', 'closed', 'closed', '', 'work-4', '', '', '2019-05-15 11:33:57', '2019-05-15 11:33:57', '', 0, 'http://portfolio.elegant/?post_type=work&#038;p=51', 0, 'work', '', 0),
(52, 1, '2019-04-22 06:52:31', '2019-04-22 06:52:31', '&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'work 5', '', 'publish', 'closed', 'closed', '', 'work-5', '', '', '2019-05-15 11:33:46', '2019-05-15 11:33:46', '', 0, 'http://portfolio.elegant/?post_type=work&#038;p=52', 0, 'work', '', 0),
(53, 1, '2019-04-22 06:53:31', '2019-04-22 06:53:31', '&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'work 6', '', 'publish', 'closed', 'closed', '', 'work-6', '', '', '2019-05-15 11:33:34', '2019-05-15 11:33:34', '', 0, 'http://portfolio.elegant/?post_type=work&#038;p=53', 0, 'work', '', 0),
(54, 1, '2019-04-22 06:54:36', '2019-04-22 06:54:36', '&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'work 7', '', 'publish', 'closed', 'closed', '', 'work-7', '', '', '2019-05-15 11:33:22', '2019-05-15 11:33:22', '', 0, 'http://portfolio.elegant/?post_type=work&#038;p=54', 0, 'work', '', 0),
(55, 1, '2019-04-22 06:56:21', '2019-04-22 06:56:21', '&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'work 8', '', 'publish', 'closed', 'closed', '', 'work-8', '', '', '2019-05-14 08:13:04', '2019-05-14 08:13:04', '', 0, 'http://portfolio.elegant/?post_type=work&#038;p=55', 0, 'work', '', 0),
(56, 1, '2019-04-22 07:27:55', '2019-04-22 07:27:55', '&nbsp;\n\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\n<div class="simple-lorem-ipsum__editmode-infobox"></div>\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'work 8', '', 'inherit', 'closed', 'closed', '', '55-autosave-v1', '', '', '2019-04-22 07:27:55', '2019-04-22 07:27:55', '', 55, 'http://portfolio.elegant/2019/04/22/55-autosave-v1/', 0, 'revision', '', 0),
(58, 1, '2019-04-22 08:23:10', '2019-04-22 08:23:10', '', 'cd-container-clmn-1-img1', '', 'inherit', 'open', 'closed', '', 'cd-container-clmn-1-img1', '', '', '2019-04-22 08:23:10', '2019-04-22 08:23:10', '', 55, 'http://portfolio.elegant/wp-content/uploads/2019/04/cd-container-clmn-1-img1.jpg', 0, 'attachment', 'image/jpeg', 0),
(59, 1, '2019-04-22 08:26:03', '2019-04-22 08:26:03', '', 'cd-container-clmn-2', '', 'inherit', 'open', 'closed', '', 'cd-container-clmn-2', '', '', '2019-04-22 08:26:03', '2019-04-22 08:26:03', '', 0, 'http://portfolio.elegant/wp-content/uploads/2019/04/cd-container-clmn-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2019-04-22 08:26:04', '2019-04-22 08:26:04', '', 'cd-container-clmn-3', '', 'inherit', 'open', 'closed', '', 'cd-container-clmn-3', '', '', '2019-04-22 08:26:04', '2019-04-22 08:26:04', '', 0, 'http://portfolio.elegant/wp-content/uploads/2019/04/cd-container-clmn-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2019-04-22 08:26:05', '2019-04-22 08:26:05', '', 'cd-container-clmn-4', '', 'inherit', 'open', 'closed', '', 'cd-container-clmn-4', '', '', '2019-04-22 08:26:05', '2019-04-22 08:26:05', '', 0, 'http://portfolio.elegant/wp-content/uploads/2019/04/cd-container-clmn-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(62, 1, '2019-04-22 08:26:07', '2019-04-22 08:26:07', '', 'cd-container-clmn-5', '', 'inherit', 'open', 'closed', '', 'cd-container-clmn-5', '', '', '2019-04-22 08:26:07', '2019-04-22 08:26:07', '', 0, 'http://portfolio.elegant/wp-content/uploads/2019/04/cd-container-clmn-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2019-04-22 08:26:08', '2019-04-22 08:26:08', '', 'cd-container-clmn-6', '', 'inherit', 'open', 'closed', '', 'cd-container-clmn-6', '', '', '2019-04-22 08:26:08', '2019-04-22 08:26:08', '', 0, 'http://portfolio.elegant/wp-content/uploads/2019/04/cd-container-clmn-6.jpg', 0, 'attachment', 'image/jpeg', 0),
(64, 1, '2019-04-22 08:26:10', '2019-04-22 08:26:10', '', 'cd-container-clmn-7', '', 'inherit', 'open', 'closed', '', 'cd-container-clmn-7', '', '', '2019-04-22 08:26:10', '2019-04-22 08:26:10', '', 0, 'http://portfolio.elegant/wp-content/uploads/2019/04/cd-container-clmn-7.jpg', 0, 'attachment', 'image/jpeg', 0),
(65, 1, '2019-04-22 08:26:12', '2019-04-22 08:26:12', '', 'cd-container-clmn-8', '', 'inherit', 'open', 'closed', '', 'cd-container-clmn-8', '', '', '2019-04-22 08:26:12', '2019-04-22 08:26:12', '', 0, 'http://portfolio.elegant/wp-content/uploads/2019/04/cd-container-clmn-8.jpg', 0, 'attachment', 'image/jpeg', 0),
(66, 1, '2019-04-22 08:33:47', '2019-04-22 08:33:47', '&nbsp;\r\n\r\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'work 9', '', 'trash', 'closed', 'closed', '', 'work-9__trashed', '', '', '2019-04-22 08:34:17', '2019-04-22 08:34:17', '', 0, 'http://portfolio.elegant/?post_type=work&#038;p=66', 0, 'work', '', 0),
(67, 1, '2019-04-22 08:33:18', '2019-04-22 08:33:18', '', 'cd-container-clmn-7', '', 'inherit', 'open', 'closed', '', 'cd-container-clmn-7-2', '', '', '2019-04-22 08:33:18', '2019-04-22 08:33:18', '', 66, 'http://portfolio.elegant/wp-content/uploads/2019/04/cd-container-clmn-7-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(69, 1, '2019-04-24 12:24:05', '2019-04-24 12:24:05', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 8', '', 'publish', 'open', 'open', '', 'this-is-the-titleof-your-post', '', '', '2019-05-04 03:59:41', '2019-05-04 03:59:41', '', 0, 'http://portfolio.elegant/?p=69', 0, 'post', '', 0),
(70, 1, '2019-04-24 12:24:16', '2019-04-24 12:24:16', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 7', '', 'publish', 'open', 'open', '', 'this-is-the-titleof-your-post-2', '', '', '2019-05-04 03:59:35', '2019-05-04 03:59:35', '', 0, 'http://portfolio.elegant/?p=70', 0, 'post', '', 0),
(71, 1, '2019-04-24 12:24:25', '2019-04-24 12:24:25', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 6', '', 'publish', 'open', 'open', '', 'this-is-the-titleof-your-post-3', '', '', '2019-05-04 03:59:28', '2019-05-04 03:59:28', '', 0, 'http://portfolio.elegant/?p=71', 0, 'post', '', 0),
(72, 1, '2019-04-24 12:24:35', '2019-04-24 12:24:35', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 5', '', 'publish', 'open', 'open', '', 'this-is-the-titleof-your-post-4', '', '', '2019-05-04 03:46:46', '2019-05-04 03:46:46', '', 0, 'http://portfolio.elegant/?p=72', 0, 'post', '', 0),
(73, 1, '2019-04-24 12:24:50', '2019-04-24 12:24:50', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 4', '', 'publish', 'open', 'open', '', 'this-is-the-titleof-your-post-5', '', '', '2019-05-04 03:46:39', '2019-05-04 03:46:39', '', 0, 'http://portfolio.elegant/?p=73', 0, 'post', '', 0),
(74, 1, '2019-04-24 12:25:16', '2019-04-24 12:25:16', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 1', '', 'publish', 'open', 'open', '', 'this-is-the-titleof-your-post-8', '', '', '2019-05-04 03:46:15', '2019-05-04 03:46:15', '', 0, 'http://portfolio.elegant/?p=74', 0, 'post', '', 0),
(75, 1, '2019-04-24 12:25:14', '2019-04-24 12:25:14', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 2', '', 'publish', 'open', 'open', '', 'this-is-the-titleof-your-post-7', '', '', '2019-05-04 03:46:23', '2019-05-04 03:46:23', '', 0, 'http://portfolio.elegant/?p=75', 0, 'post', '', 1),
(76, 1, '2019-04-24 12:25:11', '2019-04-24 12:25:11', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 3', '', 'publish', 'open', 'open', '', 'this-is-the-titleof-your-post-6', '', '', '2019-05-04 03:46:30', '2019-05-04 03:46:30', '', 0, 'http://portfolio.elegant/?p=76', 0, 'post', '', 0),
(77, 1, '2019-04-24 12:23:51', '2019-04-24 12:23:51', '', 'contact-mobile', '', 'inherit', 'open', 'closed', '', 'contact-mobile', '', '', '2019-04-24 12:23:51', '2019-04-24 12:23:51', '', 69, 'http://portfolio.elegant/wp-content/uploads/2019/04/contact-mobile.jpg', 0, 'attachment', 'image/jpeg', 0),
(78, 1, '2019-04-24 12:23:57', '2019-04-24 12:23:57', '', 'img1', '', 'inherit', 'open', 'closed', '', 'img1', '', '', '2019-04-24 12:23:57', '2019-04-24 12:23:57', '', 69, 'http://portfolio.elegant/wp-content/uploads/2019/04/img1.jpg', 0, 'attachment', 'image/jpeg', 0),
(79, 1, '2019-04-24 12:24:05', '2019-04-24 12:24:05', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2019-04-24 12:24:05', '2019-04-24 12:24:05', '', 69, 'http://portfolio.elegant/2019/04/24/69-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2019-04-24 12:24:16', '2019-04-24 12:24:16', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2019-04-24 12:24:16', '2019-04-24 12:24:16', '', 70, 'http://portfolio.elegant/2019/04/24/70-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2019-04-24 12:24:25', '2019-04-24 12:24:25', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2019-04-24 12:24:25', '2019-04-24 12:24:25', '', 71, 'http://portfolio.elegant/2019/04/24/71-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2019-04-24 12:24:35', '2019-04-24 12:24:35', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2019-04-24 12:24:35', '2019-04-24 12:24:35', '', 72, 'http://portfolio.elegant/2019/04/24/72-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2019-04-24 12:24:50', '2019-04-24 12:24:50', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2019-04-24 12:24:50', '2019-04-24 12:24:50', '', 73, 'http://portfolio.elegant/2019/04/24/73-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2019-04-24 12:25:12', '2019-04-24 12:25:12', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2019-04-24 12:25:12', '2019-04-24 12:25:12', '', 76, 'http://portfolio.elegant/2019/04/24/76-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2019-04-24 12:25:14', '2019-04-24 12:25:14', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post', '', 'inherit', 'closed', 'closed', '', '75-revision-v1', '', '', '2019-04-24 12:25:14', '2019-04-24 12:25:14', '', 75, 'http://portfolio.elegant/2019/04/24/75-revision-v1/', 0, 'revision', '', 0),
(86, 1, '2019-04-24 12:25:16', '2019-04-24 12:25:16', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2019-04-24 12:25:16', '2019-04-24 12:25:16', '', 74, 'http://portfolio.elegant/2019/04/24/74-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2019-04-24 12:30:18', '2019-04-24 12:30:18', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.\r\nAll project images by Heydays', 'Nöra', '', 'publish', 'closed', 'closed', '', 'nora', '', '', '2019-04-24 12:30:18', '2019-04-24 12:30:18', '', 0, 'http://portfolio.elegant/?post_type=project&#038;p=87', 0, 'project', '', 0),
(88, 1, '2019-04-24 12:30:29', '2019-04-24 12:30:29', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.\r\nAll project images by Heydays', 'Nöra', '', 'publish', 'closed', 'closed', '', 'nora-2', '', '', '2019-04-24 12:30:29', '2019-04-24 12:30:29', '', 0, 'http://portfolio.elegant/?post_type=project&#038;p=88', 0, 'project', '', 0),
(89, 1, '2019-04-24 12:31:18', '2019-04-24 12:31:18', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.\r\nAll project images by <strong>Heydays</strong>', 'Nöra', '', 'publish', 'closed', 'closed', '', 'nora-7', '', '', '2019-04-26 12:29:43', '2019-04-26 12:29:43', '', 0, 'http://portfolio.elegant/?post_type=project&#038;p=89', 0, 'project', '', 0),
(90, 1, '2019-04-24 12:31:17', '2019-04-24 12:31:17', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.\r\nAll project images by Heydays', 'Nöra', '', 'publish', 'closed', 'closed', '', 'nora-6', '', '', '2019-05-07 13:29:47', '2019-05-07 13:29:47', '', 0, 'http://portfolio.elegant/?post_type=project&#038;p=90', 0, 'project', '', 0),
(91, 1, '2019-04-24 12:31:16', '2019-04-24 12:31:16', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.\r\nAll project images by Heydays', 'Nöra', '', 'publish', 'closed', 'closed', '', 'nora-5', '', '', '2019-04-24 12:31:16', '2019-04-24 12:31:16', '', 0, 'http://portfolio.elegant/?post_type=project&#038;p=91', 0, 'project', '', 0),
(92, 1, '2019-04-24 12:31:14', '2019-04-24 12:31:14', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.\r\nAll project images by Heydays', 'Nöra', '', 'publish', 'closed', 'closed', '', 'nora-4', '', '', '2019-04-24 12:31:14', '2019-04-24 12:31:14', '', 0, 'http://portfolio.elegant/?post_type=project&#038;p=92', 0, 'project', '', 0),
(93, 1, '2019-04-24 12:31:12', '2019-04-24 12:31:12', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.\r\nAll project images by Heydays', 'Nöra', '', 'publish', 'closed', 'closed', '', 'nora-3', '', '', '2019-04-24 12:31:12', '2019-04-24 12:31:12', '', 0, 'http://portfolio.elegant/?post_type=project&#038;p=93', 0, 'project', '', 0),
(95, 1, '2019-04-26 11:24:35', '2019-04-26 11:24:35', '', 'img2', '', 'inherit', 'open', 'closed', '', 'img2', '', '', '2019-04-26 11:24:35', '2019-04-26 11:24:35', '', 89, 'http://portfolio.elegant/wp-content/uploads/2019/04/img2.jpg', 0, 'attachment', 'image/jpeg', 0),
(96, 1, '2019-04-26 11:24:37', '2019-04-26 11:24:37', '', 'img3', '', 'inherit', 'open', 'closed', '', 'img3', '', '', '2019-04-26 11:24:37', '2019-04-26 11:24:37', '', 89, 'http://portfolio.elegant/wp-content/uploads/2019/04/img3.jpg', 0, 'attachment', 'image/jpeg', 0),
(97, 1, '2019-04-26 11:24:38', '2019-04-26 11:24:38', '', 'img4', '', 'inherit', 'open', 'closed', '', 'img4', '', '', '2019-04-26 11:24:38', '2019-04-26 11:24:38', '', 89, 'http://portfolio.elegant/wp-content/uploads/2019/04/img4.jpg', 0, 'attachment', 'image/jpeg', 0),
(98, 1, '2019-04-26 12:29:37', '2019-04-26 12:29:37', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.\nAll project images by <strong>Heydays</strong>', 'Nöra', '', 'inherit', 'closed', 'closed', '', '89-autosave-v1', '', '', '2019-04-26 12:29:37', '2019-04-26 12:29:37', '', 89, 'http://portfolio.elegant/2019/04/26/89-autosave-v1/', 0, 'revision', '', 0),
(99, 1, '2019-04-27 16:21:07', '2019-04-27 16:21:07', 'slkfjslkjf;askf;aslkjfsa', 'Main', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-04-27 16:21:07', '2019-04-27 16:21:07', '', 19, 'http://portfolio.elegant/2019/04/27/19-revision-v1/', 0, 'revision', '', 0),
(100, 1, '2019-04-27 16:21:24', '2019-04-27 16:21:24', '', 'Main', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-04-27 16:21:24', '2019-04-27 16:21:24', '', 19, 'http://portfolio.elegant/2019/04/27/19-revision-v1/', 0, 'revision', '', 0),
(101, 1, '2019-04-28 07:03:04', '2019-04-28 07:03:04', 'Lorem ipsum dolor sit amet, conse tetuer adi piscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore.', 'Tobias Schneider', '', 'publish', 'closed', 'closed', '', 'tobias-schneider', '', '', '2019-04-28 07:03:04', '2019-04-28 07:03:04', '', 0, 'http://portfolio.elegant/?post_type=people&#038;p=101', 0, 'people', '', 0),
(102, 1, '2019-04-28 07:02:56', '2019-04-28 07:02:56', '', 'man1', '', 'inherit', 'open', 'closed', '', 'man1', '', '', '2019-04-28 07:02:56', '2019-04-28 07:02:56', '', 101, 'http://portfolio.elegant/wp-content/uploads/2019/04/man1.jpg', 0, 'attachment', 'image/jpeg', 0),
(103, 1, '2019-04-28 07:05:03', '2019-04-28 07:05:03', 'Lorem ipsum dolor sit amet, conse tetuer adi piscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore.', 'Jack Knife', '', 'publish', 'closed', 'closed', '', 'jack-knife', '', '', '2019-04-28 07:05:03', '2019-04-28 07:05:03', '', 0, 'http://portfolio.elegant/?post_type=people&#038;p=103', 0, 'people', '', 0),
(104, 1, '2019-04-28 07:05:38', '2019-04-28 07:05:38', 'Lorem ipsum dolor sit amet, conse tetuer adi piscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore.', 'Ricki Hall', '', 'publish', 'closed', 'closed', '', 'ricki-hall', '', '', '2019-05-18 08:18:20', '2019-05-18 08:18:20', '', 0, 'http://portfolio.elegant/?post_type=people&#038;p=104', 0, 'people', '', 0),
(105, 1, '2019-04-28 07:04:59', '2019-04-28 07:04:59', '', 'man2', '', 'inherit', 'open', 'closed', '', 'man2', '', '', '2019-04-28 07:04:59', '2019-04-28 07:04:59', '', 103, 'http://portfolio.elegant/wp-content/uploads/2019/04/man2.jpg', 0, 'attachment', 'image/jpeg', 0),
(106, 1, '2019-04-28 07:05:33', '2019-04-28 07:05:33', '', 'man3', '', 'inherit', 'open', 'closed', '', 'man3', '', '', '2019-04-28 07:05:33', '2019-04-28 07:05:33', '', 104, 'http://portfolio.elegant/wp-content/uploads/2019/04/man3.jpg', 0, 'attachment', 'image/jpeg', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(114, 1, '2019-05-04 03:46:15', '2019-05-04 03:46:15', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 1', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2019-05-04 03:46:15', '2019-05-04 03:46:15', '', 74, 'http://portfolio.elegant/2019/05/04/74-revision-v1/', 0, 'revision', '', 0),
(115, 1, '2019-05-04 03:46:23', '2019-05-04 03:46:23', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 2', '', 'inherit', 'closed', 'closed', '', '75-revision-v1', '', '', '2019-05-04 03:46:23', '2019-05-04 03:46:23', '', 75, 'http://portfolio.elegant/2019/05/04/75-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2019-05-04 03:46:30', '2019-05-04 03:46:30', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 3', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2019-05-04 03:46:30', '2019-05-04 03:46:30', '', 76, 'http://portfolio.elegant/2019/05/04/76-revision-v1/', 0, 'revision', '', 0),
(117, 1, '2019-05-04 03:46:39', '2019-05-04 03:46:39', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 4', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2019-05-04 03:46:39', '2019-05-04 03:46:39', '', 73, 'http://portfolio.elegant/2019/05/04/73-revision-v1/', 0, 'revision', '', 0),
(118, 1, '2019-05-04 03:46:46', '2019-05-04 03:46:46', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 5', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2019-05-04 03:46:46', '2019-05-04 03:46:46', '', 72, 'http://portfolio.elegant/2019/05/04/72-revision-v1/', 0, 'revision', '', 0),
(119, 1, '2019-05-04 03:46:51', '2019-05-04 03:46:51', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 5', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2019-05-04 03:46:51', '2019-05-04 03:46:51', '', 71, 'http://portfolio.elegant/2019/05/04/71-revision-v1/', 0, 'revision', '', 0),
(120, 1, '2019-05-04 03:47:00', '2019-05-04 03:47:00', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 6', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2019-05-04 03:47:00', '2019-05-04 03:47:00', '', 70, 'http://portfolio.elegant/2019/05/04/70-revision-v1/', 0, 'revision', '', 0),
(121, 1, '2019-05-04 03:47:11', '2019-05-04 03:47:11', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 7', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2019-05-04 03:47:11', '2019-05-04 03:47:11', '', 69, 'http://portfolio.elegant/2019/05/04/69-revision-v1/', 0, 'revision', '', 0),
(122, 1, '2019-05-04 03:59:28', '2019-05-04 03:59:28', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 6', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2019-05-04 03:59:28', '2019-05-04 03:59:28', '', 71, 'http://portfolio.elegant/2019/05/04/71-revision-v1/', 0, 'revision', '', 0),
(123, 1, '2019-05-04 03:59:35', '2019-05-04 03:59:35', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 7', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2019-05-04 03:59:35', '2019-05-04 03:59:35', '', 70, 'http://portfolio.elegant/2019/05/04/70-revision-v1/', 0, 'revision', '', 0),
(124, 1, '2019-05-04 03:59:41', '2019-05-04 03:59:41', 'This looks. I want to complexity. That\'s come to testify to complexity. It\'s about an object, we kept going and i figured out some basic stuff that acknowledges its very minimalist way beyond the traditions of function from a clutterfree product that form and value on ideas and simplicity. What products have disconnected function of anything of the computer.', 'This is the Titleof Your Post 8', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2019-05-04 03:59:41', '2019-05-04 03:59:41', '', 69, 'http://portfolio.elegant/2019/05/04/69-revision-v1/', 0, 'revision', '', 0),
(125, 1, '2019-05-13 12:19:13', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-05-13 12:19:13', '0000-00-00 00:00:00', '', 0, 'http://portfolio.elegant/?p=125', 0, 'post', '', 0),
(126, 2, '2019-05-16 06:35:52', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-05-16 06:35:52', '0000-00-00 00:00:00', '', 0, 'http://portfolio.elegant/?p=126', 0, 'post', '', 0),
(127, 2, '2019-05-16 06:38:01', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-05-16 06:38:01', '0000-00-00 00:00:00', '', 0, 'http://portfolio.elegant/?p=127', 0, 'post', '', 0),
(128, 2, '2019-05-16 06:38:11', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-05-16 06:38:11', '0000-00-00 00:00:00', '', 0, 'http://portfolio.elegant/?post_type=work&p=128', 0, 'work', '', 0),
(129, 1, '2019-05-18 10:35:13', '2019-05-18 10:35:13', 'sdfsddfsdfsd', 'Main', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-05-18 10:35:13', '2019-05-18 10:35:13', '', 19, 'http://portfolio.elegant/2019/05/18/19-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(130, 1, '2019-05-18 10:42:39', '2019-05-18 10:42:39', '<h2>sdfsfsfsdf</h2>\r\n&nbsp;\r\n\r\nsdfsddfsdfsd', 'Main', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-05-18 10:42:39', '2019-05-18 10:42:39', '', 19, 'http://portfolio.elegant/2019/05/18/19-revision-v1/', 0, 'revision', '', 0),
(131, 1, '2019-05-18 10:43:08', '2019-05-18 10:43:08', '<h2>sdfsfsfsdf</h2>\r\n&nbsp;\r\n\r\nsdfsddfsdfsd\r\n\r\nsadfsdfsdfsafsdf sf fsdf s fsf sd', 'Main', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-05-18 10:43:08', '2019-05-18 10:43:08', '', 19, 'http://portfolio.elegant/2019/05/18/19-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2019-05-18 10:44:49', '2019-05-18 10:44:49', '', 'Main', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-05-18 10:44:49', '2019-05-18 10:44:49', '', 19, 'http://portfolio.elegant/2019/05/18/19-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(25, 2, 0),
(26, 2, 0),
(27, 2, 0),
(28, 2, 0),
(33, 1, 0),
(35, 2, 0),
(36, 2, 0),
(69, 1, 0),
(70, 4, 0),
(71, 6, 0),
(72, 5, 0),
(73, 1, 0),
(74, 4, 0),
(75, 6, 0),
(76, 5, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'nav_menu', '', 0, 6),
(4, 4, 'category', '', 0, 2),
(5, 5, 'category', '', 0, 2),
(6, 6, 'category', '', 0, 2) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Art', 'art', 0),
(2, 'Menu 1', 'menu-1', 0),
(4, 'Business', 'business', 0),
(5, 'Design', 'design', 0),
(6, 'Code', 'code', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '125'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:12:"192.168.43.0";}'),
(19, 1, 'wp_user-settings', 'mfold=o&libraryContent=browse'),
(20, 1, 'wp_user-settings-time', '1555682320'),
(22, 1, 'closedpostboxes_work', 'a:1:{i:0;s:11:"postexcerpt";}'),
(23, 1, 'metaboxhidden_work', 'a:1:{i:0;s:7:"slugdiv";}'),
(24, 1, 'meta-box-order_page', 'a:3:{s:4:"side";s:36:"submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:45:"postcustom,commentstatusdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(25, 1, 'screen_layout_page', '2'),
(26, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(27, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(28, 1, 'nav_menu_recently_edited', '2'),
(29, 1, 'closedpostboxes_nav-menus', 'a:0:{}'),
(30, 1, 'wp_media_library_mode', 'grid'),
(41, 2, 'nickname', 'user'),
(42, 2, 'first_name', ''),
(43, 2, 'last_name', ''),
(44, 2, 'description', ''),
(45, 2, 'rich_editing', 'true'),
(46, 2, 'syntax_highlighting', 'true'),
(47, 2, 'comment_shortcuts', 'false'),
(48, 2, 'admin_color', 'fresh'),
(49, 2, 'use_ssl', '0'),
(50, 2, 'show_admin_bar_front', 'true'),
(51, 2, 'locale', ''),
(52, 2, 'wp_capabilities', 'a:1:{s:6:"author";b:1;}'),
(53, 2, 'wp_user_level', '2'),
(54, 2, 'dismissed_wp_pointers', 'wp496_privacy'),
(56, 2, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(57, 2, 'wp_user-settings', 'mfold=f'),
(58, 2, 'wp_user-settings-time', '1557988489'),
(61, 2, 'wp_dashboard_quick_press_last_post_id', '126'),
(66, 1, 'session_tokens', 'a:1:{s:64:"e900a3322784ef4fc386b94cb50b8f304326c9b17abc674ad1f67a2a18f421bb";a:4:{s:10:"expiration";i:1558339498;s:2:"ip";s:13:"192.168.43.34";s:2:"ua";s:77:"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0";s:5:"login";i:1558166698;}}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BHS/m3lnypWTLKYguIw2TANQBBVwmp1', 'admin', 'victor8titov@yandex.ru', '', '2019-04-17 17:03:21', '', 0, 'admin'),
(2, 'user', '$P$Bn6ywwMn4V9tVG/la9ztjVMQB3/T9b1', 'user', 'none@none.none', '', '2019-05-16 06:33:59', '1557988442:$P$BfPzXI95xHG8U3mFPXXk5SGIYio9as/', 0, 'user') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

